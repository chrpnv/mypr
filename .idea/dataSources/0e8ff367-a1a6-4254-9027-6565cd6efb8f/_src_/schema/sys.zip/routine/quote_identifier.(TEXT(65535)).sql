CREATE FUNCTION sys.quote_identifier(in_identifier TEXT(65535))
  RETURNS TEXT CHARSET UTF8 (65535)
BEGIN RETURN CONCAT('`', REPLACE(in_identifier, '`', '``'), '`'); END
;
